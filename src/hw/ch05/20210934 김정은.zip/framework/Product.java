package hw.ch05.framework;

public abstract class Product {
    //public abstract Product(String name);//문제 4-3 내용. 생성자는 상속되지 않아 오류 발생
    public abstract void use();
}
